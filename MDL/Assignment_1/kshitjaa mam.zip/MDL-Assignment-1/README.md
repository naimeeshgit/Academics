# Machine Data and Learning
## Assignment 1

### Team members:
- [Rishabh Khanna](https://github.com/kyabacchahai)
- [Kshitijaa Jaglan](https://github.com/deutranium)
