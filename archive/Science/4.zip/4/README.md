## Assignment 4


### How to run

* Type the following commands to run

```
    python -m venv venv
    source venv/bin/activate
    pip install -r requirements.txt
    jupyter lab
```

* Run the program cell by cell for all notebooks present.