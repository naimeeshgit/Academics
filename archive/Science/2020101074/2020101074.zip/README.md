# 2020101074
# Naimeesh Narayan Tiwari


# Q1:

- scale is set such that 1 unit = 10 A
- we first find a random point in this cubic space
- then reject those points which are at a dist > 6A and dist < 5A
- then store these and plot


# Q2:
- to get the total potential Energy use the formula taught in the class 
- Apply it for the points obtained in Q1 in pairs
- and then add all the pairwise results

